'use strict';

for (let i = '*'; i.length <=20; i += '*') {
    console.log(i);
}